#!/bin/bash

read pass

while [ $pass != abc ]
do 
read pass
done
echo Password Matched

